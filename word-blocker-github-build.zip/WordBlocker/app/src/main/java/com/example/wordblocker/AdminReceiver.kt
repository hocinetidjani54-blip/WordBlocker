package com.example.wordblocker

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * عند تفعيله يصبح حذف التطبيق يتطلب إلغاء تفعيله أولًا من إعدادات الهاتف،
 * وتظهر رسالة تحذير أثناء القفل.
 */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return if (Prefs.isLocked(context)) {
            val d = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                .format(Date(Prefs.lockUntil(context)))
            "التطبيق مقفل حتى $d. التزامك بالقفل هو الهدف، فلا تلغِ الحماية الآن."
        } else {
            "سيصبح بإمكانك حذف التطبيق بعد إلغاء الحماية."
        }
    }
}
