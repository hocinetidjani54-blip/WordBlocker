package com.example.wordblocker

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val sv = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 70, 40, 40)
        }
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun tv(text: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, 16, 0, 8)
    }

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
    }

    private fun fmt(t: Long) =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(t))

    private fun accessibilityOn(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains(packageName)
    }

    private fun adminComponent() = ComponentName(this, AdminReceiver::class.java)

    private fun adminOn(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent())
    }

    private fun render() {
        root.removeAllViews()
        root.addView(tv("🚫 حاجب الكلمات", 24f, true))

        // 1) خدمة إمكانية الوصول
        if (accessibilityOn()) {
            root.addView(tv("✅ خدمة الحظر تعمل"))
        } else {
            root.addView(tv("⚠️ خدمة الحظر متوقفة. فعّلها من إعدادات إمكانية الوصول."))
            root.addView(btn("فتح إعدادات إمكانية الوصول") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        }

        // 2) حماية من الحذف
        if (adminOn()) {
            root.addView(tv("✅ حماية الحذف مفعّلة"))
        } else {
            root.addView(btn("تفعيل حماية الحذف (مدير الجهاز)") {
                val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
                    .putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "يمنع حذف التطبيق قبل إلغاء هذه الحماية يدويًا."
                    )
                startActivity(i)
            })
        }

        // 3) نطاق الحظر
        val scope = CheckBox(this).apply {
            text = "في المتصفحات فقط (بدل كل التطبيقات)"
            isChecked = Prefs.browsersOnly(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                if (!Prefs.setBrowsersOnly(this@MainActivity, checked)) {
                    Toast.makeText(
                        this@MainActivity, "لا يمكن التخفيف أثناء القفل", Toast.LENGTH_SHORT
                    ).show()
                    render()
                }
            }
        }
        root.addView(scope)

        // 4) الكلمات
        root.addView(tv("الكلمات المحظورة", 18f, true))
        val input = EditText(this).apply { hint = "اكتب كلمة لحظرها" }
        root.addView(input)
        root.addView(btn("إضافة") {
            val w = input.text.toString().trim()
            if (w.isNotEmpty()) {
                Prefs.addWord(this, w)
                render()
            }
        })

        val words = Prefs.words(this).sorted()
        if (words.isEmpty()) root.addView(tv("لا توجد كلمات بعد"))
        for (w in words) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(TextView(this).apply {
                text = w
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(btn("حذف") {
                if (Prefs.removeWord(this, w)) {
                    render()
                } else {
                    Toast.makeText(
                        this, "مقفل حتى ${fmt(Prefs.lockUntil(this))}", Toast.LENGTH_LONG
                    ).show()
                }
            })
            root.addView(row)
        }

        // 5) القفل الزمني
        root.addView(tv("القفل الزمني", 18f, true))
        if (Prefs.isLocked(this)) {
            root.addView(tv("🔒 مقفل حتى ${fmt(Prefs.lockUntil(this))}\nلا يمكن حذف الكلمات قبل ذلك."))
        } else {
            root.addView(tv("غير مقفل. بعد القفل لا يمكن حذف الكلمات ولا التخفيف حتى تنتهي المدة."))
        }
        val days = EditText(this).apply {
            hint = "عدد الأيام"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        root.addView(days)
        root.addView(btn("قفل / تمديد القفل") {
            val d = days.text.toString().toIntOrNull()
            if (d == null || d <= 0) {
                Toast.makeText(this, "أدخل عدد أيام صحيحًا", Toast.LENGTH_SHORT).show()
            } else {
                Prefs.extendLock(this, d)
                render()
            }
        })
    }
}
