package com.example.wordblocker

import android.content.Context
import java.text.Normalizer

/** توحيد النص: حروف صغيرة، حذف التشكيل والتطويل، توحيد الألف والياء والهاء. */
fun norm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFKD)
        .replace(Regex("[\\u064B-\\u065F\\u0670\\u0640\\u0300-\\u036F]"), "")
        .replace(Regex("[\\u0623\\u0625\\u0622\\u0671]"), "ا")
        .replace('ى', 'ي')
        .replace('ة', 'ه')

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("wb", Context.MODE_PRIVATE)

    /** الوقت الحالي، مع منع الغش بإرجاع الساعة للخلف (نحتفظ بأكبر وقت شوهد). */
    fun now(c: Context): Long {
        val s = sp(c)
        val n = maxOf(System.currentTimeMillis(), s.getLong("maxSeen", 0L))
        s.edit().putLong("maxSeen", n).apply()
        return n
    }

    fun words(c: Context): Set<String> =
        sp(c).getStringSet("words", emptySet())!!.toSet()

    fun addWord(c: Context, w: String) {
        sp(c).edit().putStringSet("words", words(c) + w).apply()
    }

    fun lockUntil(c: Context): Long = sp(c).getLong("lockUntil", 0L)

    fun isLocked(c: Context): Boolean = lockUntil(c) > now(c)

    /** الحذف مسموح فقط عندما لا يكون القفل فعّالًا. */
    fun removeWord(c: Context, w: String): Boolean {
        if (isLocked(c)) return false
        sp(c).edit().putStringSet("words", words(c) - w).apply()
        return true
    }

    /** القفل يمكن تمديده فقط، ولا يمكن تقصيره. */
    fun extendLock(c: Context, days: Int) {
        val target = now(c) + days * 86_400_000L
        if (target > lockUntil(c)) sp(c).edit().putLong("lockUntil", target).apply()
    }

    fun browsersOnly(c: Context): Boolean = sp(c).getBoolean("browsersOnly", true)

    /** أثناء القفل لا يمكن التخفيف (التحويل إلى "المتصفحات فقط")، بل التشديد فقط. */
    fun setBrowsersOnly(c: Context, v: Boolean): Boolean {
        if (v && isLocked(c)) return false
        sp(c).edit().putBoolean("browsersOnly", v).apply()
        return true
    }
}
