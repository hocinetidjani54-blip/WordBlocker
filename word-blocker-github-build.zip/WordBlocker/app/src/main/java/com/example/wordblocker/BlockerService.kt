package com.example.wordblocker

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class BlockerService : AccessibilityService() {

    private val lastGood = HashMap<String, String>()
    private var browsers: Set<String> = emptySet()

    override fun onServiceConnected() {
        super.onServiceConnected()
        browsers = findBrowsers()
    }

    /** كل تطبيق يفتح روابط https يُعتبر متصفحًا (يشمل Tor Browser وChrome وFirefox...). */
    private fun findBrowsers(): Set<String> {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
            .addCategory(Intent.CATEGORY_BROWSABLE)
        val set = packageManager
            .queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName }
            .toMutableSet()
        set += listOf(
            "org.torproject.torbrowser", "org.torproject.torbrowser_alpha",
            "com.android.chrome", "org.mozilla.firefox", "com.brave.browser",
            "com.microsoft.emmx", "com.opera.browser", "com.google.android.googlequicksearchbox"
        )
        return set
    }

    private fun hasBlocked(text: String): Boolean {
        val n = norm(text)
        return Prefs.words(this).any { w ->
            val nw = norm(w).trim()
            nw.isNotEmpty() && n.contains(nw)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (Prefs.browsersOnly(this) && pkg !in browsers) return
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_VIEW_FOCUSED
        ) return

        val node = event.source ?: return
        if (!node.isEditable || node.isPassword) return

        val text = node.text?.toString() ?: ""
        val key = pkg + ":" + (node.viewIdResourceName ?: "")

        if (hasBlocked(text)) {
            val prev = lastGood[key].orEmpty().let { if (hasBlocked(it)) "" else it }
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, prev)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            val sel = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, prev.length)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, prev.length)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
            Toast.makeText(this, "🚫 هذه الكلمة محظورة", Toast.LENGTH_SHORT).show()
        } else {
            lastGood[key] = text
        }
    }

    override fun onInterrupt() {}
}
